package com.suje.dao.headerHtml;

public interface MemberHeaderDao {

}
