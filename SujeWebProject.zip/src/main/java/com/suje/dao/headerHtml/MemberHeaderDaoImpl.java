package com.suje.dao.headerHtml;

public class MemberHeaderDaoImpl implements MemberHeaderDao {

}
