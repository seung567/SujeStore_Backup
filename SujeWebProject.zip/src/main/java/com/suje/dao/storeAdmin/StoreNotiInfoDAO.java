package com.suje.dao.storeAdmin;

import com.suje.domain.storeAdmin.StoreNoticeVO;

public interface StoreNotiInfoDAO {

	 public void insertStoreNotiInfo(StoreNoticeVO vo); 
}
