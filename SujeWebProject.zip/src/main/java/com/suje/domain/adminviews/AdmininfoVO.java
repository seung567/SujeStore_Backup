package com.suje.domain.adminviews;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdmininfoVO {
    private String MA_ID; 
    private String MA_PASS; 
    private String MA_NAME; 
    private String MA_EMAIL; 
    private String MA_TEL; 
}
