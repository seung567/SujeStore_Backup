package com.suje.domain.customer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountVO {
	int m_acc_code;
	String m_id, m_acc_bank, m_acc_num;
}
