package com.suje.domain.storeAdmin;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoreAccountVO {
	String s_id, s_pass, s_bnum,s_tel,s_email,s_addr,s_bank,s_spname;
	long s_acc;
}
