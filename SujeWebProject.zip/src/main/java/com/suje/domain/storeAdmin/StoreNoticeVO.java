package com.suje.domain.storeAdmin;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StoreNoticeVO {

	int noti_code, notit_code; 
	String s_id, noti_content; 
	String notir_date, notim_date; 
	
}
