package com.suje.service.storeAdmin;

import com.suje.domain.storeAdmin.StoreNoticeVO;

public interface StoreNotiInfoService {
	
	
	public void insertStoreNotiInfo(StoreNoticeVO vo);
}
